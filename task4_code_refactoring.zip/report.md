# Task 4: Code Refactoring and Performance Optimization

## 🎯 Objective

Refactor a small function to improve **performance** and **readability**.

---

## 📂 Function Refactored

Function to sum all even numbers up to `n` (inclusive).

---

## 🔎 Original Code

- Iterates through every number up to `n`
- Checks if each number is even using modulo operation
- Adds even numbers to a running total

### ❌ Issues:
- Uses unnecessary loop and conditionals
- Time complexity: **O(n)**

---

## ✅ Refactored Code

- Uses **mathematical formula** for sum of arithmetic progression
- Only computes based on the last even number
- No loops used

### ✅ Benefits:
- Time complexity: **O(1)**
- More readable and concise

---

## 📈 Performance Improvement

| Input `n` | Original Time Complexity | Refactored Time Complexity |
|-----------|--------------------------|-----------------------------|
| 10        | O(n) = 10 steps          | O(1) = 1 step               |
| 1000000   | O(n) = 1 million steps   | O(1) = 1 step               |

---

## 📌 Conclusion

Mathematical refactoring removed unnecessary iteration and made the function **significantly faster**, especially for large inputs.
// Optimized: Sum all even numbers up to n (inclusive)
function sumEvenNumbers(n) {
  const lastEven = n % 2 === 0 ? n : n - 1;
  const numberOfEvens = Math.floor(lastEven / 2);
  return numberOfEvens * (2 + lastEven) / 2;
}